# xm_msgs

Create Date: 2015.6.17

Authors: Luke Liao, startar  

Function: This ros package includes some necessary message and service or action file. They can be used for xm_robot to achieve many function by realizing interface.
